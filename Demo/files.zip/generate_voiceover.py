#!/usr/bin/env python3
"""
Generate per-segment voiceover for the Adaptive GenAI Learning Tutor demo.

- Calls ElevenLabs Text-to-Speech (eleven_multilingual_v2) once per segment.
- Writes voiceover/01_intro.mp3 ... voiceover/07_close.mp3
- Per-segment files let you drop each clip onto its matching scene in the editor
  so narration lines up with on-screen actions.

Optional --timestamps uses the with-timestamps endpoint and also writes
voiceover/<id>.json with word-level timing (great for caption generation and
for cutting the screen recording exactly to the narration).

Setup (Pro account):
    export ELEVENLABS_API_KEY=sk_...        # from elevenlabs.io -> Developer -> API Key
    python generate_voiceover.py --voice <VOICE_ID>
    python generate_voiceover.py --voice <VOICE_ID> --timestamps

Pick a narrator voice from your Voice Library and pass its ID. The default below
is a placeholder. No pip install required (uses the standard library only).

Optional: stitch all clips into one track (loses per-scene alignment):
    ffmpeg -f concat -safe 0 -i <(for f in voiceover/0*.mp3; do echo "file '$PWD/$f'"; done) \
           -c copy voiceover/full.mp3
"""
import os
import sys
import json
import base64
import argparse
import pathlib
import urllib.request
import urllib.error

API_BASE = "https://api.elevenlabs.io/v1/text-to-speech"
MODEL_ID = "eleven_multilingual_v2"   # swap to "eleven_v3" for more expressive delivery
OUTPUT_FORMAT = "mp3_44100_192"        # 192 kbps available on Pro; use mp3_44100_128 otherwise
OUT_DIR = pathlib.Path("voiceover")

VOICE_SETTINGS = {"stability": 0.5, "similarity_boost": 0.75, "style": 0.0}

# (segment_id, narration text). Keep one segment per scene.
SEGMENTS = [
    ("01_intro",
     "This is the Adaptive GenAI Learning Tutor, my Week 3 build for the Mastering "
     "Agentic AI Bootcamp. Most AI tutors are just chat wrappers. They hallucinate, "
     "they don't track what you actually know, and the feedback is generic. I wanted "
     "the opposite. An agent that assesses you first, teaches only from a real source "
     "corpus, and grades your answers in code instead of vibes. The one job here is "
     "simple. Take a learner from a cold start to a graded, source-cited exercise in "
     "under five minutes."),
    ("02_architecture",
     "Under the hood it's a deep agent, built on LangGraph with the deepagents "
     "framework. One orchestrator plans the work and delegates to four specialists. "
     "A diagnostic agent, a path planner, an exercise author, and a grader critic. "
     "They share a set of tools. Four are read-only. Search the corpus, assess skills, "
     "view progress, and recommend a path. Three of them write. Generate an exercise, "
     "grade an answer, and commit progress. Grading is fully deterministic. It runs in "
     "Python against a rubric, so the agent can't talk its way to a better score. And "
     "committing progress is gated behind a human approval step, which you'll see in a "
     "second."),
    ("03_diagnostic_path",
     "Let's run it live. I'll tell it what I want to learn. I want to learn about RAG "
     "and AI agents. The diagnostic subagent kicks off, searches the corpus for both "
     "topics, and works out where I'm starting from. Everything it says is pulled from "
     "the research corpus, not invented. Now I'll ask what to study first. It comes "
     "back with a prerequisite-aware path, and every topic links straight to its "
     "source."),
    ("04_exercise_grading",
     "Now the real test. Give me an exercise on RAG. The exercise author writes a "
     "question with a deterministic rubric attached. I'll answer it. I'm describing "
     "retrieval with vector similarity and grounding the answer in cited snippets. "
     "When I submit, the grader scores it in code against that rubric. I get a score, "
     "the exact criteria I covered and the ones I missed, and citations back to the "
     "corpus so I know where to go deeper. No vague good job. A verdict I can actually "
     "trust."),
    ("05_human_in_the_loop",
     "Before any of this gets saved, the agent stops. This is the human-in-the-loop "
     "gate. The commit-progress tool fires an interrupt, shows me exactly what it wants "
     "to write, and waits. I review it, I approve, and only then does my progress get "
     "persisted. Reads run on their own. Anything that writes has to earn a human."),
    ("06_tracing_security",
     "Two things I'm proud of. First, the whole run is traced in LangSmith, so you can "
     "watch the orchestrator hand off to each subagent, see every tool call, and catch "
     "the interrupt state. Second, security. I ran an OWASP audit against the Top Ten "
     "for Web, for LLMs, and for Agentic AI, using Claude Code with a custom audit "
     "prompt, and fixed twenty-one findings. Prompt-injection filtering, per-tenant "
     "memory isolation, signed state, token budgets. The agent layer, the subagent "
     "wiring, and that audit loop were all vibe-coded with Claude Code and Codex "
     "against the deepagents docs."),
    ("07_close",
     "That's the build. Cold start to graded feedback in under five minutes. Grounded, "
     "deterministic, with a human in control of anything that writes. The code and the "
     "live app are linked below. Thanks for watching."),
]


def synth(seg_id: str, text: str, voice: str, with_ts: bool) -> None:
    suffix = "/with-timestamps" if with_ts else ""
    url = f"{API_BASE}/{voice}{suffix}?output_format={OUTPUT_FORMAT}"
    payload = json.dumps({
        "text": text,
        "model_id": MODEL_ID,
        "voice_settings": VOICE_SETTINGS,
    }).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        method="POST",
        headers={
            "xi-api-key": os.environ["ELEVENLABS_API_KEY"],
            "Content-Type": "application/json",
            "Accept": "application/json" if with_ts else "audio/mpeg",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read()
    except urllib.error.HTTPError as e:
        sys.exit(f"[{seg_id}] HTTP {e.code}: {e.read().decode('utf-8', 'replace')}")

    mp3_path = OUT_DIR / f"{seg_id}.mp3"
    if with_ts:
        data = json.loads(body)
        mp3_path.write_bytes(base64.b64decode(data["audio_base64"]))
        (OUT_DIR / f"{seg_id}.json").write_text(
            json.dumps(data.get("alignment", {}), indent=2)
        )
    else:
        mp3_path.write_bytes(body)
    print(f"  wrote {mp3_path}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--voice", default="JBFqnCBsd6RMkjVDRZzb",
                    help="ElevenLabs voice ID from your Voice Library")
    ap.add_argument("--timestamps", action="store_true",
                    help="also write word-level timing JSON per segment")
    args = ap.parse_args()

    if "ELEVENLABS_API_KEY" not in os.environ:
        sys.exit("Set ELEVENLABS_API_KEY first.")

    OUT_DIR.mkdir(exist_ok=True)
    print(f"Generating {len(SEGMENTS)} segments with {MODEL_ID} (voice {args.voice})...")
    for seg_id, text in SEGMENTS:
        synth(seg_id, text, args.voice, args.timestamps)
    print("Done. Clips are in ./voiceover/")


if __name__ == "__main__":
    main()
