# Handoff — Record the Week 3 Demo Video (Adaptive GenAI Learning Tutor)

You are picking up a finished, verified project. Your job: **record a demo video (5:00 or less) and produce an ElevenLabs voiceover for it.** Do not change the app's code. The app works and has been verified live.

## What the deliverable is
A screen-recorded walkthrough of the live app with an ElevenLabs voiceover, for the "Mastering Agentic AI Bootcamp" Week 3 submission. The video must: walk through the app, explain what was built, describe how AI coding tools were used, and demonstrate the result live. Hard cap 5:00.

## The app (already built and deployed)
- **Live app:** https://tutor-ui-production.up.railway.app/ — auto-authenticates as `demo-learner`. No login, no credentials needed. Never enter a password.
- **Repo:** https://github.com/dglabsxyz/adaptive-genai-learning-tutor
- **What it is:** an adaptive learning tutor built as a deep agent (LangGraph + deepagents). An orchestrator plans and uses tutor tools to diagnose a learner, plan a prerequisite-aware study path, author exercises, and grade answers **deterministically in Python** against a rubric. Writes (like saving progress) are gated behind a human-approval step. Stack: FastAPI, Qwen-Plus via DashScope, Nebius Token Factory, Supabase, Vite/React, Railway.

## Verified facts (keep the narration accurate to these)
- Grading is deterministic. A strong (4/4) answer advances a skill by **+0.12, capped**. Verified live: RAG went **0.42 → 0.54** on a 4/4 and **stayed "developing."**
- A single exercise **never jumps a proficiency band** and never reaches "proficient" from "developing." Do **not** let the narration claim a skill became "proficient" from one exercise. Proficiency rises *within* a band; that is the honest story.
- The chat now reports the **same** numbers the store holds (the old fabricated-number bug is fixed). The Progress bar genuinely moves after grading.
- Chat turns take **~30–60s**. The app shows a "Tutor is working…" state. Worst case on camera is a clean "let me try that again" message — never a 500, a dead-end, or a fabricated number.
- The **Practice tab is deterministic** (one REST call, no agent) and shows the identical graded loop. It is your reliable anchor and your fallback if any single chat turn stumbles on camera.

## Recording plan (record in this order)
This is the most reliable, most visual sequence. Generate the voiceover FIRST, then record screen while playing it back so actions land on the narration.

1. **Dashboard** — open here. Proficiency donut + ten-skill breakdown. Strong visual hook. (Narration Segment 1: the problem.)
2. **Architecture beat** — show the architecture diagram from the repo README, or narrate over the dashboard. (Segment 2.)
3. **Diagnostic tab** — run/show a quick diagnostic. (Segment 3, part 1.)
4. **Study Plan tab** — show the prerequisite-aware path with source links. (Segment 3, part 2.)
5. **Practice tab** — get an exercise, submit an answer, show the deterministic graded rubric (score + covered/missed + citations). This is the anchor; it cannot stumble. (Segment 4.)
6. **Progress tab** — show the skill bar move after the graded answer (it really moves now, within the band). (Ties Segment 4 → 5.)
7. **Tutor Chat** — one short exchange to show the conversational deep agent and the **human-in-the-loop approval gate** when saving progress. Narrate the ~30–60s latency as the agent "planning and delegating." If a turn stumbles, cut to the Practice clip — same loop. (Segment 5.)
8. **Close** — repo + live URL on screen. (Segment 7.)

Optional if you have time under 5:00 (Segment 6): a LangSmith trace screenshot + one line on the OWASP/Claude Code security hardening and the AI coding tools used. Cut this first if you run long.

Tip: to start from a clean baseline, the Progress page has a Reset control. If you reset, RAG returns to its starting point so the on-camera "first attempt → bar moves" reads cleanly.

## Voiceover (ElevenLabs)
Two files are in this folder:
- `demo-narration-script.md` — the timed, segmented narration script (under 5:00 spoken).
- `generate_voiceover.py` — zero-dependency batch generator with all 7 segments baked in.

Steps:
1. The user sets their own key: `export ELEVENLABS_API_KEY=...` (Pro account). Do not ask them to paste the key into chat; they set the env var themselves.
2. Pick a narrator voice ID from their ElevenLabs Voice Library.
3. Run: `python generate_voiceover.py --voice <VOICE_ID> --timestamps`
4. Output: `voiceover/01_intro.mp3 … 07_close.mp3` plus word-level timing JSON per segment. Model is `eleven_multilingual_v2` at 192 kbps (Pro). Switch `MODEL_ID` to `eleven_v3` for more expressiveness if desired.

## Assemble
- Per-scene clips: drop each MP3 onto its matching scene in the editor (DaVinci Resolve or CapCut), using the timing JSON to align cuts to the narration.
- Trim the "Tutor is working…" dead air on chat turns.
- Export an MP4, **5:00 or less**.

## Guardrails
- Do not modify app code. This is a recording task.
- App auto-logs in as `demo-learner`; no credentials. Never enter passwords or API keys into web forms.
- The ElevenLabs API key is provided by the user as an environment variable; never print it.
- Keep narration honest: deterministic grading, proficiency rising within "developing," human approval for writes. No "proficient from one exercise."
