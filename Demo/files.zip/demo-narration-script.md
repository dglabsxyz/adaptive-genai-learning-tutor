# Adaptive GenAI Learning Tutor — Demo Narration Script

**Target length:** under 5:00 (spoken ~4:40, leaving buffer for action pauses)
**Voice model:** ElevenLabs `eleven_multilingual_v2` (stable, lifelike, built for narration)
**Style:** first-person, direct, no filler. Pause ~1s between segments so actions land on the narration.

**Reference — the one-liner (don't read verbatim, it's distilled in Segment 1):**
> My agent helps learners master Generative AI concepts in a web app + MCP interface, replacing the hours of unstructured self-study with no feedback loop. It diagnoses knowledge gaps, recommends study paths, generates exercises, and grades answers on its own across 4 specialized subagents, hands off to a human before persisting progress changes, and I'll know it works when a learner can complete a diagnostic → exercise → grading cycle in under 5 minutes with deterministic, source-cited feedback.

---

## Timing map

| # | Segment | Window | ~Duration |
|---|---------|--------|-----------|
| 1 | Intro / the problem | 0:00–0:30 | 30s |
| 2 | Architecture | 0:30–1:15 | 45s |
| 3 | Live: diagnostic + path | 1:15–2:10 | 55s |
| 4 | Live: exercise + grading | 2:10–3:05 | 55s |
| 5 | Human-in-the-loop commit | 3:05–3:35 | 30s |
| 6 | Tracing, security, AI tooling | 3:35–4:25 | 50s |
| 7 | Close | 4:25–4:40 | 15s |

---

## Segment 1 — Intro / the problem
**[ON SCREEN]** App landing page at tutor-ui-production.up.railway.app (or a title card).

> This is the Adaptive GenAI Learning Tutor, my Week 3 build for the Mastering Agentic AI Bootcamp. Most AI tutors are just chat wrappers. They hallucinate, they don't track what you actually know, and the feedback is generic. I wanted the opposite. An agent that assesses you first, teaches only from a real source corpus, and grades your answers in code instead of vibes. The one job here is simple. Take a learner from a cold start to a graded, source-cited exercise in under five minutes.

## Segment 2 — Architecture
**[ON SCREEN]** The architecture diagram (orchestrator + 4 subagents) from the README, or a slide of it.

> Under the hood it's a deep agent, built on LangGraph with the deepagents framework. One orchestrator plans the work and delegates to four specialists. A diagnostic agent, a path planner, an exercise author, and a grader critic. They share a set of tools. Four are read-only. Search the corpus, assess skills, view progress, and recommend a path. Three of them write. Generate an exercise, grade an answer, and commit progress. Grading is fully deterministic. It runs in Python against a rubric, so the agent can't talk its way to a better score. And committing progress is gated behind a human approval step, which you'll see in a second.

## Segment 3 — Live: diagnostic + path
**[ON SCREEN]** Type into the chat. Let the diagnostic run. Then ask for a path; show the source links.

> Let's run it live. I'll tell it what I want to learn. I want to learn about RAG and AI agents. The diagnostic subagent kicks off, searches the corpus for both topics, and works out where I'm starting from. Everything it says is pulled from the research corpus, not invented. Now I'll ask what to study first. It comes back with a prerequisite-aware path, and every topic links straight to its source.

## Segment 4 — Live: exercise + grading
**[ON SCREEN]** Ask for an exercise. Type an answer. Submit. Show the score, covered/missed criteria, and citations.

> Now the real test. Give me an exercise on RAG. The exercise author writes a question with a deterministic rubric attached. I'll answer it. I'm describing retrieval with vector similarity and grounding the answer in cited snippets. When I submit, the grader scores it in code against that rubric. I get a score, the exact criteria I covered and the ones I missed, and citations back to the corpus so I know where to go deeper. No vague good job. A verdict I can actually trust.

## Segment 5 — Human-in-the-loop commit
**[ON SCREEN]** The interrupt / approval gate appears. Review what will be saved. Approve. Progress persists.

> Before any of this gets saved, the agent stops. This is the human-in-the-loop gate. The commit-progress tool fires an interrupt, shows me exactly what it wants to write, and waits. I review it, I approve, and only then does my progress get persisted. Reads run on their own. Anything that writes has to earn a human.

## Segment 6 — Tracing, security, AI tooling
**[ON SCREEN]** Switch to LangSmith trace tree (orchestrator → subagents → tool calls → interrupt). Then flash the security report / Claude Code audit.

> Two things I'm proud of. First, the whole run is traced in LangSmith, so you can watch the orchestrator hand off to each subagent, see every tool call, and catch the interrupt state. Second, security. I ran an OWASP audit against the Top Ten for Web, for LLMs, and for Agentic AI, using Claude Code with a custom audit prompt, and fixed twenty-one findings. Prompt-injection filtering, per-tenant memory isolation, signed state, token budgets. The agent layer, the subagent wiring, and that audit loop were all vibe-coded with Claude Code and Codex against the deepagents docs.

## Segment 7 — Close
**[ON SCREEN]** Repo URL + live app URL on screen.

> That's the build. Cold start to graded feedback in under five minutes. Grounded, deterministic, with a human in control of anything that writes. The code and the live app are linked below. Thanks for watching.

---

## Recording notes
- Generate the voiceover first (run `generate_voiceover.py`), then play it back while you click through, so your actions line up with the words.
- Segments 3, 4, and 5 are the live parts. Rehearse the exact prompts once so the agent's responses come back clean on the take.
- If a subagent step is slow on camera, trim the dead air in your editor and let the narration carry it.
- Keep the whole thing under 5:00. If you run long, Segment 6 is the easiest to tighten.
